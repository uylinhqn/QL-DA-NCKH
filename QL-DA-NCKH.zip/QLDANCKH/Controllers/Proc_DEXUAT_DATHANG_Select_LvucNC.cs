﻿namespace QLDANCKH.Controllers
{
    public class Proc_DEXUAT_DATHANG_Select_LvucNC
    {
    }
}